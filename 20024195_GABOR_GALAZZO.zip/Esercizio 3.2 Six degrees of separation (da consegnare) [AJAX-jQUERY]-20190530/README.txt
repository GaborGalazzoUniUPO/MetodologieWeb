<GABOR,GALAZZO,20024195>

Esercizio 3.2: Six degrees of separation(PHP, Ajax, jQuery e DBMS MySQL)

Note: Anziché usare il metodo PDO::query io creo dei prepared statment.

L'applicativo è una singol page web app (tutto dentro index)

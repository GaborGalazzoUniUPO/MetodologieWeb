<!-- <GABOR,GALAZZO,20024195> -->
<?php include("top.html"); ?>

<!-- Exercise 2 - Find nerds
     This provided file is the front page that links to two of the files you are going
     to write, signup.php and matches.php.  You don't need to modify this file. -->
<div>
	<h1>Welcome!</h1>

	<ul>
		<li>
			<a href="signup.php">
				<img src="http://www.cs.washington.edu/education/courses/cse190m/12sp/homework/4/signup.gif" alt="icon" >
				Sign up for a new account
			</a>
		</li>
		
		<li>
			<a href="matches.php">
				<img src="http://www.cs.washington.edu/education/courses/cse190m/12sp/homework/4/heartbig.gif" alt="icon" >
				Check your matches
			</a>
		</li>
	</ul>
</div>

<?php include("bottom.html"); ?>

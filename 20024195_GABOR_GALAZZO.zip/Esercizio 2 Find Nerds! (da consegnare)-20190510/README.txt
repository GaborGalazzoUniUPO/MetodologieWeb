<GABOR,GALAZZO,20024195>

Esercizio 2: Find nerds(PHP,FORMS e FILES)

Note: Questo esercizio è stato arricchito con la gestione "Politically Correct"
Inoltre come files aggiuntivi per la gestione del codice ridondante sono state fatte
delle Classi PHP.
il file autoload.php implementa una funzione di autoload delle classi della direcotry class/
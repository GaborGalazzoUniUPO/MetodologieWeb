<!-- <GABOR,GALAZZO,20024195> -->
<!-- Metodologie per il web - A.A. 2018/2019 - Esercizio 3: Six degrees of separation - Kevin Bacon -->

<?php include("top.html"); ?>

<h1>The One Degree of Kevin Bacon</h1>
<p>Type in an actor's name to see if he/she was ever in a movie with Kevin Bacon!</p>
<p><img src="http://www.cs.washington.edu/education/courses/cse190m/12sp/homework/5/kevin_bacon.jpg" alt="Kevin Bacon" ></p>

<?php include("bottom.html"); ?>

<GABOR,GALAZZO,20024195>

Esercizio 3: Six degrees of separation(PHP e DBMS MySQL)

Note: Anziché usare il metodo PDO::query io creo dei prepared statment